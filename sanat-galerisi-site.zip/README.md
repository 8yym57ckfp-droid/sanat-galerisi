# Sanat Atölyesi — Perihan Baktaş

GitHub Pages ile yayınlanmaya hazır, tek sayfalı sanat galerisi sitesidir.

## Açma

```
index.html dosyasını bir tarayıcıda açın.
```

## Yayınlama

Depoda **Settings → Pages** bölümünden `Deploy from a branch` seçin ve kök klasörü (/) yayınlayın.

## İçerik

- `index.html`: Sayfa, CSS, JavaScript, fontlar ve görsel varlıkları tek dosyada içerir.
- Ek Java veya Python sunucusu gerekmez; site statiktir ve GitHub Pages üzerinde çalışır.
